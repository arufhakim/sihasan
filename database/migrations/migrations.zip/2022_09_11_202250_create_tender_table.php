<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTenderTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tender', function (Blueprint $table) {
            $table->id();
            $table->string('tender');
            $table->string('no_sp', 50);
            $table->string('no_agreement', 50);
            $table->string('vendor');
            $table->string('prosentase');
            $table->date('periode_awal');
            $table->date('periode_akhir');
            $table->mediumText('keterangan');
            $table->string('oleh', 100)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tender');
    }
}
